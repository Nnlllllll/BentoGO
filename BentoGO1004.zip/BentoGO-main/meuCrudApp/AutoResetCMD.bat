@echo off
setlocal enabledelayedexpansion


set PORTA=3000
set SUBS=bentogo-main bentogo-v2 bentogo-temp


:inicio
for %%s in (%SUBS%) do (
    echo [!date! !time!] 🚀 Tentando subdominio: %%s
    
    call npx localtunnel --port %PORTA% --subdomain %%s
    
    echo.
    echo ⚠️ Conexao perdida ou dominio ocupado. 
    echo 🔄 Rotacionando para o proximo em 2 segundos...
    timeout /t 2 >nul
)
goto inicio
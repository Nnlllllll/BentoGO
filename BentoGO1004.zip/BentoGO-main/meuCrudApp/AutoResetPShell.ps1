$subs = @("bentogo-main", "bentogo-v2", "bentogo-temp")
$index = 0

while ($true) {
    $atual = $subs[$index]
    Write-Host "🚀 Ligando túnel em: $atual" -ForegroundColor Cyan
    
    npx localtunnel --port 3000 --subdomain $atual
    
    Write-Host "⚠️ Caiu! Rotacionando subdomínio..." -ForegroundColor Yellow
    $index = ($index + 1) % $subs.Count
    Start-Sleep -Seconds 1
}
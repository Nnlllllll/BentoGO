import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const localtunnel = require('localtunnel');
import { Linking } from 'react-native';

import MainScreen from './src/screens/MainScreen';

const Stack = createNativeStackNavigator();

const startLocalTunnel = async () => {
    const tunnel = await localtunnel({ port: 3001 });
    console.log(`Tunnel URL: ${tunnel.url}`);
    Linking.openURL(tunnel.url);
};

startLocalTunnel();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Main" component={MainScreen} />
        
      </Stack.Navigator>
    </NavigationContainer>
  );
}
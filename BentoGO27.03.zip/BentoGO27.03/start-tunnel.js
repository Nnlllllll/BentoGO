const ngrok = require('ngrok');

(async () => {
  try {
    const url = await ngrok.connect(3001);
    console.log(`Ngrok tunnel URL: ${url}`);
    // Keep the process running to maintain the tunnel
    process.stdin.resume();
  } catch (error) {
    console.error('Error starting ngrok:', error);
  }
})();
